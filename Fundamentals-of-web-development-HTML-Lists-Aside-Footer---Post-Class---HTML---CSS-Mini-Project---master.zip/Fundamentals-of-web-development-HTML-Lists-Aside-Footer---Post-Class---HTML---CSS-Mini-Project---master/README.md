# html-css-project-boilerplate
# Project's Title
RestoBar website 
Live Demo visit this link : https://62a97c28e3e65a4c59257930--extraordinary-madeleine-3f4103.netlify.app/

# Table of content
* [Project Description](#Project-Description)
* [Technologies Used](#technologies-used)
* [Setup](#setup)
* [Usage](#usage)
* [Project Status](#project-status)
* [Room for Improvement](#room-for-improvement)
* [Acknowledgements](#acknowledgements)
* [Contact](#contact)

## Project Description:
This project is about RestoBAr Website , in which all information about RestoBar , and services at RestoBar . In this website i used parallex effect to show different photos of RestoBar in the website & made 4 container to get my parallex effect.I also created static nav bar or menu list at the top  Right of  website .I also add some form input , to get get from user , while this website is static once i improve or devlop more into it and javascript help me to do so.
During coding , I learn many things about this technologies i used in it, i.e. HTML & CSS. To create a parallex effect into website its very difficult for me once i  know things about it become soo easy for myself to add this effect in my project.

## Technologies Used:
I used two basic technology :
1 HTML : Html is used to create a static webpages , it is very easy to understand and helpful to build simple website .
2.CSS : Css is just add on HTML , CSS stands for CASCADING Style Sheet, which help to add various styling into our web page and also help us to do styling Externally.

Parallax Effect  is a scrolling technique used in computer graphics in which background images move more slowly than images in the foreground, creating the illusion of depth and immersion. It is often used in video games.
The word "parallax" is taken from astronomy and defined as the apparent displacement or the difference in apparent direction of something when viewed from two different vantage points.

In the world of digital graphics, programmers can achieve parallax scrolling in different ways. One involves creating different layers that move at uneven speeds when rendered in a browser or other viewer. Alternately, programmers can create "sprites," or independent parts of an image, often in the form of avatars or characters that move within a digital landscape. The cycling of repeating patterns is another technique that has been useful in many video game projects and other animations, and programmers can also manipulate the rendering of raster graphics or bitmapped visuals to create parallax scrolling.

In general, developers have to consider various elements to create a parallax scrolling effect with integrity and versatility. For example, one approach involves the creation of image layers through attribution, followed by assigning a scroll function and designating speeds for each item, then adding any HTML or CSS fixes for different browsers or viewers. As with other kinds of visual projects, incorporating the right syntax of the latest versions of these resources are crucial to developing a parallax scrolling technique that works well.
 
## Setup :
To setup you have to follow following steps :
### Step 1: Add your new site
Once you've logged in, it will take you to a home dashboard. Click the New site from git button to add your new website to Netlify.
### Step 2: Link to your GitHub
When you click the New site from git button, it will take you to the "Create a new site" page. Make sure that you push your repository on GitHub so that Netlify can link to your GitHub account.

### Step 3: Authorize Netlify
Next, click the Authorize Netlify by Netlify button. This permission is needed so that both Netlify and GitHub can connect.

### Step 4: Select your repository
Once you grant permission to Netlify, you can see a list of all your repositories. Select your website to publish. You can find it by either scrolling down the list or using the search bar to narrow down the list.

### Step 5: Configure your settings
After selecting your website, you will be prompted to configure the settings for deploying the website. Since your website is simply a static one, there's not much to do here. Just click Deploy site to continue.

### Step 6: Publish your website
Your website is now ready to publish! Netlify will do the rest of the work for you, and it will only take a minute or so to complete the process.
Now you are done! Your new website is published, and you can view it by clicking the green link.

Right now, your URL looks random, but you can edit it by clicking the Site settings button and then the Change site name button.
Congratulation on publishing your first new website!
 
## Usage :
This helps customers to book their tables ,and also help to get  quick view of RestoBar before coming in it. All information  attaractive images encourage him to come at RestoBAr.I made this website because, it's one of my dream project, listed in mind that i have to do in future .Thats why i make try on it for self motivation.

## Project Status:
Currently , this is a intial website or we case a static website  I made for reference and as mini project, this project currently at intial stage that is Static stage .

## Room of Improvment :
There are various improvment that i will add on for further improvment like adding Java Script into it, make it dynamic , and also i will api or use data base for collecting data from the users.

## Acknowledegements :
First of all i would like to thank you Newton School to present my skills in the form this Mini project. This things really motivate us and boost self confidence which will really good advantage in the future.

## Contact :
Name : Aditya Giri
Email : adityakumargoswami03@gmail.com
phone number : 7987265992 
